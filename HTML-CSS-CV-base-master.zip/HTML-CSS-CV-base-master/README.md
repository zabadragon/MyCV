# CV base

Podstawa projektu do pobrania. Pełen tutorial z opisem na blogu Fly Nerd: CV w HTML / CSS

### Zakres

Celem projektu jest wykorzystanie stworzenie strony www własnego CV za użyciem HTML i CSS.

### Z tym tutorialem:
- wykorzystasz znaczniki HTML5
- ostylujesz stronę za pomocą CSS
- stworzysz prosty, czytelny i estetyczny layout
- wykorzystasz flexbox do tworzenia układu strony
- przystosujesz stronę pod urządzenia mobilne (RWD)

### Wymagania
Do wykonania zadań konieczna jest podstawowa znajomość HTML i CSS!